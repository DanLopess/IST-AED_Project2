/************
*************
May 8th '18

All Rights Reserved © Daniel Lopes

File: task.c
Project: Tasks management
*************
Description:
This auxiliary file contains all the implementations to tasks
*************/
#include "task.h"
#include "hash.h"

/*Global variables*/
int criticalPathCalculated = 0; /*controls the status of the critical Path */

void cleanBuffer(){
	char c;
	while((c=getchar()) != '\n');
}

Item readItem(List x){ /*Reads a certain task without dependencies*/
	long int id,duration; /*allows to decide if a negative number was read*/
	Item task = (Item)malloc(sizeof(struct task));
	if(scanf("%ld \"%8001[^\"]\"%ld*[' ']",&id,task->description,&duration) != 3){
		printf("illegal arguments\n");
		cleanBuffer();
		free(task);
		return NULL;
	}
	else{
		if(!nonExistant(x,id)){ /*replace for STsearch*/
			printf("id already exists\n");
			cleanBuffer();
			return NULL;
		}
		else if(id > 0 && duration > 0){
			task->id = (Key)id;
			task->duration = (Key)duration;
			return task;
		}
		else{
			printf("illegal arguments\n");
			cleanBuffer();
			return NULL;
		}
	}
}

void addItem(Item task, List x){
	Key readId;
	int readDependency = 0;

	if(task != NULL){
		task->dependencies = (List) malloc(sizeof(struct list));
		listInit(task->dependencies);
		while(scanf("%lu", &readId) == 1 && readId > 0){
			readDependency = 1;
			if(nonExistant(x,readId)){ /*replace for STsearch*/
				printf("no such task\n");
				free(task->dependencies);
				free(task);
				return;
			}
			else{
				Key *tempId = (Key*) malloc(sizeof(Key)); /*need to realloc*/
				*tempId = readId;
				addNode(task->dependencies,tempId);
			}
		}
		if(!readDependency)
			deleteList(task->dependencies);
		addNode(x,task);
		criticalPathCalculated = 0;
	}
	else
		free(task);
}

int nonExistant(List x, Key id){ /*replace for hash table*/
	link i;

	for(i = x->head; i != NULL; i = i->next)
		if(((Item)i->item)->id == id)
			return 0; /*existant*/
	return 1; /*nonexistant*/
}

void removeItem(List x){
	link i;
	long int tempId; /*to see if id is positive*/
	Key id;
	int nodeRemoved=0;

	if(scanf("%ld*['\n']", &tempId)==1 && tempId > 0){
		id = (Key)tempId;
		if(!nonExistant(x,id)){ /*replace for STsearch*/
			for (i = x->head; i != NULL; i = i->next){
				if(((Item)i->item)->id == id){ /* item is void* so it needs to be casted*/
					if(listEmpty(((Item)i->item)->dependencies)){ /*If it has zero dependencies*/
						removeNode(x,i); /* also apply to STdelete*/
						removeDependency(x,id);
						nodeRemoved = 1;
						criticalPathCalculated = 0;
						break;
					}
					else{
						printf("task with dependencies\n");
						nodeRemoved = 1;
					}
				}
			}
			if (!nodeRemoved)
				printf("no such task\n"); /*trocar para procurar na hashtable*/
		}
		else
			printf("no such task\n");
	}
	else{
		printf("illegal arguments\n");
		cleanBuffer();
	}
}

void removeDependency(List x, Key id){ /*removes from all lists of dependencies*/
	link i,f;
	for(i = x->head; i!=NULL; i=i->next){
		for(f = ((Item)i->item)->dependencies->head; f!=NULL; f=f->next)
			if(*(((Key*)f->item)) == id)
				removeNode(((Item)i->item)->dependencies,f);
	}
}

void printItem(Item t){
	link i;

	printf("%ld \"%s\" %ld",t->id, t->description, t->duration);
	if(!listEmpty(t->dependencies))
		for(i = t->dependencies->head; i != NULL; i = i->next){
			printf(" %lu", *((Key*)i->item));
		}
	printf("\n");
}

void duration(List x){
	Key duration;
	link i;
	if(!criticalPathCalculated){
		if(scanf("%lu", &duration) == 1){
			for(i = x->head; i != NULL; i = i->next){
				if(((Item)i->item)->duration >= duration)
					printItem(i->item);
			}
		}
		else{
			for(i = x->head; i != NULL; i = i->next)
				printItem(i->item);
		}
	}
	else{
		/*print early and start*/
	}
}


void depend(List x){ /*BUGS*/
	Key id;
	if (scanf("%lu", &id) == 1){
		link i;
		int foundDependency = 0;
		if(!nonExistant(x,id)){ /*replace for STsearch*/
			printf("%lu:", id);
			for(i = x->head; i != NULL; i = i->next){
				if(((Item)i->item)->id == id){
					if(!listEmpty(((Item)i->item)->dependencies))
						for(i = ((Item)i->item)->dependencies->head; i != NULL; i = i->next){
							printf("printing id: ");
							printf(" %lu", *((Key*)i->item));
						}
				}
			}
			if(!foundDependency){
				printf(" no dependencies\n");
			}
		}
		else{
			printf("no such task\n");
		}
	}
	else{
		printf("illegal arguments\n");
		cleanBuffer();
	}
}


void deleteAllTasks(List x){ /*Delete list of tasks*/
	link t;
	if(!listEmpty(x)){
		for(t = x->head; t->next != NULL; t = t->next){
			deleteList(((Item)t->item)->dependencies);
			free(((Item)t->item)->dependencies); /*now free the list completely*/
		}
	}
	deleteList(x);
	free(x);
}

void path(List x){ /*nao recalcular os elementos ja calculados*/

}
