Nota:
- As funções relativas ao teste prático, encontram-se sempre na main de cada projeto.
